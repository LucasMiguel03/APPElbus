import styled from 'styled-components/native';

export const Container = styled.SafeAreaView`
    flex: 1;
    background-color: #FFF;
`;

export const Header = styled.View`
    display: flex;
    height: 174.5px;
`;

export const HeaderSpace = styled.View`
    width: 286px;
    height: 70px;
    margin-left: 20px;
    margin-right: 53.43px;
    margin-top: 41px;
`;
export const HeaderTitle = styled.Text`
    font-size: 40px;
    color: #394452;
    font-family: Montserrat;
    font-weight: bold;
`;

export const HeaderTitleBusaqui = styled.Text`
    font-size: 40px;
    color: blue;
    font-family: Montserrat;
    font-weight: bold;
`;
