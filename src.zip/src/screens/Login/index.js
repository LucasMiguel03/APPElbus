import React from 'react';
import { Container, Header, HeaderSpace, HeaderTitle, HeaderTitleBusaqui } from './styled';

const Page = () => {
    return (
      <Container>
        <Header>
          <HeaderSpace>
            <HeaderTitle>Bem-Vindo ao</HeaderTitle>
            <HeaderTitleBusaqui>Busaqui <HeaderTitle>!!!</HeaderTitle></HeaderTitleBusaqui>
          </HeaderSpace>
        </Header>
      </Container>
    );
  }

export default Page;